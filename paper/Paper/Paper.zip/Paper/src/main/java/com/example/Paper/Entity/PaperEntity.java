package com.example.Paper.Entity;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "crp")
public class PaperEntity {
    @Id
    private int paperId;
    private String title;
    private String keywords;
    private String authorName;
    private int pageCount;
    private LocalDate subDate;
    private int authorId;
    private int regId;
    public PaperEntity()
    {

    }
    public PaperEntity(int paperId, String title, String keywords,String authorName,int pageCount,LocalDate subDate,int authorId,int regId) {
        this.paperId = paperId;
        this.title = title;
        this.keywords = keywords;
        this.authorName = authorName;
        this.pageCount = pageCount;
        this.subDate = subDate;
        this.authorId = authorId;
        this.regId = regId;
    }
    public int getPaperId() {
        return paperId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getKeywords() {
        return keywords;
    }
    
    public String getAuthorName() {
        return authorName;
    }
    
    public int getPageCount() {
        return pageCount;
    }
    
    public LocalDate getSubDate() {
        return subDate;
    }
    
    public int getAuthorId() {
        return authorId;
    }
    
    public int getRegId() {
        return regId;
    }
    
    @Override
public String toString() {
    return "Crp [paperId=" + paperId +", title=" + title +", keywords=" + keywords +", authorName=" + authorName +", pageCount=" + pageCount +", subDate=" + subDate +", authorId=" + authorId +", regId=" + regId + "]";
}


public void setPaperId(int paperId) {
    this.paperId = paperId;
}

public void setTitle(String title) {
    this.title = title;
}

public void setKeywords(String keywords) {
    this.keywords = keywords;
}

public void setAuthorName(String authorName) {
    this.authorName = authorName;
}

public void setPageCount(int pageCount) {
    this.pageCount = pageCount;
}

public void setSubDate(LocalDate subDate) {
    this.subDate = subDate;
}

public void setAuthorId(int authorId) {
    this.authorId = authorId;
}

public void setRegId(int regId) {
    this.regId = regId;
}

    // Getters and setters
}

