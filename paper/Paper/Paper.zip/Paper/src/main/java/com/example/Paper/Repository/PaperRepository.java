package com.example.Paper.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Paper.Entity.PaperEntity;

 
public interface PaperRepository extends JpaRepository<PaperEntity, Integer> {
}