package com.example.Paper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaperApplicationTests {

	@Test
	void contextLoads() {
	}

}
