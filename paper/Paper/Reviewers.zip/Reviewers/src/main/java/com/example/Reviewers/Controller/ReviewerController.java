package com.example.Reviewers.Controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Reviewers.Entity.ReviewerEntity;
import com.example.Reviewers.Repository.ReviewerRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "Reviewer Management", description = "Operations related to reviewers") 
public class ReviewerController {
    @Autowired
    private ReviewerRepository reviewerRepository;

    @GetMapping("/test")
    @Operation(summary = "Test Method", description = "Returns a greeting message.")
    public String getMethodName() {
        return "Hello Sachin";
    }

    @GetMapping("/reviewers")
    @Operation(summary = "Get All Reviewers", description = "Retrieves all reviewers.")
    public List<ReviewerEntity> getAllReviewers() {
        return reviewerRepository.findAllByOrderByIdAsc();
    }

    @GetMapping("/reviewers/{id}")
    @Operation(summary = "Get Reviewer by ID", description = "Retrieves a reviewer by their ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful retrieval"),
        @ApiResponse(responseCode = "404", description = "Reviewer not found")
    })
    public Optional<ReviewerEntity> getReviewerById(@PathVariable("id") Integer id) {
        return reviewerRepository.findById(id);
    }

    @PostMapping("/reviewers")
    @Operation(summary = "Create Reviewer", description = "Creates a new reviewer.")
    public ReviewerEntity createReviewer(@RequestBody ReviewerEntity reviewer) {
        return reviewerRepository.save(reviewer);
    }

    @PutMapping("/reviewers")
    @Operation(summary = "Update Reviewer", description = "Updates an existing reviewer.")
    public ReviewerEntity updateReviewer(@RequestBody ReviewerEntity reviewer) {
        return reviewerRepository.save(reviewer);
    }

    @PutMapping("/reviewers/{id}")
    @Operation(summary = "Full Update Reviewer", description = "Replaces an existing reviewer by their ID.")
    public ReviewerEntity putMethodName(@PathVariable("id") int id, @RequestBody ReviewerEntity reviewer) {
        Optional<ReviewerEntity> temOptional = reviewerRepository.findById(id);
        if (temOptional.isPresent()) {
            return reviewerRepository.save(reviewer);
        } else {
            return reviewerRepository.save(reviewer);
        }
    }

    @PatchMapping("/reviewers/{id}")
    @Operation(summary = "Partial Update Reviewer", description = "Updates specific fields of an existing reviewer.")
    public ReviewerEntity patchReviewer(@PathVariable("id") int id, @RequestBody Map<String, Object> updates) {
        Optional<ReviewerEntity> existingReviewerOptional = reviewerRepository.findById(id);
        if (existingReviewerOptional.isPresent()) {
            ReviewerEntity existingReviewer = existingReviewerOptional.get();
            updates.forEach((key, value) -> {
                switch (key) {
                    case "name":
                        existingReviewer.setName((String) value);
                        break;
                    case "email":
                        existingReviewer.setEmail((String) value);
                        break;
                    case "affiliation":
                        existingReviewer.setAffiliation((String) value);
                        break;
                    case "expertise":
                        existingReviewer.setExpertise((String) value);
                        break;
                }
            });
            return reviewerRepository.save(existingReviewer);
        } else {
            throw new RuntimeException("Reviewer with id " + id + " not found");
        }
    }

    @DeleteMapping("/reviewers/{id}")
    @Operation(summary = "Delete Reviewer by ID", description = "Deletes a reviewer by their ID.")
    public String deleteReviewerById(@PathVariable("id") int id) {
        reviewerRepository.deleteById(id);
        return "deleted";
    }
}