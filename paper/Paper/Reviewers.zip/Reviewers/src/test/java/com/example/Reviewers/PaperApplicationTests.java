package com.example.Reviewers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewerApplicationTests {

    @Test
    void contextLoads() {
    }

}